// 表格渲染：把 xlsx 的每个工作表画成 HTML 表格。
//
// 单独放在 assets 里的原因：直接在 Java 字符串里拼 JS，转义会把人逼疯（试过一次，
// 编译报错 10 条）。放进 zip 后 Java 只负责把这段脚本内联进页面。
//
// 关键细节：公式格如果文件里没有缓存值（<v> 空），SheetJS 读出来就是空白。
// 这里把它显式改成 "=公式"，并标注原因——宁可看见公式，也不要看见一片空白。

function renderSheet(b64, out) {
  var bytes = Uint8Array.from(atob(b64), function (ch) { return ch.charCodeAt(0); });
  var wb = XLSX.read(bytes, { type: 'array', cellFormula: true });
  wb.SheetNames.forEach(function (name) {
    var h = document.createElement('div');
    h.className = 'sheetname';
    h.textContent = name;
    out.appendChild(h);

    var ws = wb.Sheets[name];
    var html = XLSX.utils.sheet_to_html(ws, { editable: false });
    var wrap = document.createElement('div');
    wrap.className = 'sheetwrap';
    wrap.innerHTML = html;
    out.appendChild(wrap);

    markFormulas(ws, wrap);
    markLimits(ws, wrap, out);
  });
}

// 没有缓存值的公式格：显示 =公式 本身
function markFormulas(ws, wrap) {
  Object.keys(ws).forEach(function (k) {
    if (k.charAt(0) === '!') return;
    var cell = ws[k];
    if (!cell || !cell.f) return;
    var hasValue = cell.v !== undefined && cell.v !== null && cell.v !== '';
    if (hasValue) return;

    var td = wrap.querySelector('td[data-r="' + cell.r + '"][data-c="' + cell.c + '"]');
    if (!td) return;
    td.textContent = '=' + cell.f;
    td.title = '公式：文件里没有缓存值，需要表格软件重算';
    td.style.color = '#9a6a00';
    td.style.fontFamily = 'ui-monospace, monospace';
  });
}

// 工作表很大时给一句提示，别让用户以为数据丢了
function markLimits(ws, wrap, out) {
  var ref = ws['!ref'];
  if (!ref) return;
  var range = XLSX.utils.decode_range(ref);
  var rows = range.e.r - range.s.r + 1;
  var cols = range.e.c - range.s.c + 1;
  if (rows * cols <= 2000) return;
  var tip = document.createElement('div');
  tip.className = 'limit';
  tip.textContent = '这张表 ' + rows + ' 行 × ' + cols + ' 列，整张渲染可能很慢；'
    + '需要精确数据建议用「用其他应用打开」。';
  out.appendChild(tip);
}
